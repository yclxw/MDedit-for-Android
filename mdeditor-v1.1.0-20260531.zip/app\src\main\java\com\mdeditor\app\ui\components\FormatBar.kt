package com.mdeditor.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mdeditor.app.ui.theme.ButtonActive
import com.mdeditor.app.ui.theme.ButtonInactive
import com.mdeditor.app.util.LineParser.LineType

enum class FormatAction {
    BODY, H1, H2, H3, H4, H5, INDENT_LEFT, INDENT_RIGHT, ORDERED_LIST, COLOR_PICKER, BOLD
}

@Composable
fun FormatBar(
    currentLineType: LineType,
    onAction: (FormatAction) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth().height(44.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            // H1-H5 heading buttons
            FormatButton("H1", currentLineType == LineType.HEADING_1, 11.sp) { onAction(FormatAction.H1) }
            FormatButton("H2", currentLineType == LineType.HEADING_2, 11.sp) { onAction(FormatAction.H2) }
            FormatButton("H3", currentLineType == LineType.HEADING_3, 11.sp) { onAction(FormatAction.H3) }
            FormatButton("H4", currentLineType == LineType.HEADING_4, 11.sp) { onAction(FormatAction.H4) }
            FormatButton("H5", currentLineType == LineType.HEADING_5, 11.sp) { onAction(FormatAction.H5) }
            // Separator
            Separator()
            // Bold
            FormatButton("B", false, 12.sp, bold = true) { onAction(FormatAction.BOLD) }
            // Separator
            Separator()
            // Indent
            FormatButton("←", false, 14.sp) { onAction(FormatAction.INDENT_LEFT) }
            FormatButton("→", false, 14.sp) { onAction(FormatAction.INDENT_RIGHT) }
            // Separator
            Separator()
            // Ordered list
            FormatButton("1.", currentLineType == LineType.ORDERED_LIST) { onAction(FormatAction.ORDERED_LIST) }
            // Spacer to push color button to far right
            Spacer(Modifier.weight(1f))
            // Single color button at far right
            ColorSwatch(
                color = Color(0xFF007AFF),
                onClick = { onAction(FormatAction.COLOR_PICKER) }
            )
        }
    }
}

@Composable
private fun Separator() {
    Box(Modifier.width(1.dp).height(24.dp).background(MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)))
}

@Composable
private fun ColorSwatch(color: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(26.dp)
            .clip(CircleShape)
            .background(color)
            .clickable(onClick = onClick)
    )
}

@Composable
private fun FormatButton(
    label: String, isActive: Boolean, labelSize: androidx.compose.ui.unit.TextUnit = 13.sp,
    bold: Boolean = false, onClick: () -> Unit
) {
    val c = if (isActive) ButtonActive else ButtonInactive
    Box(
        Modifier.height(30.dp).clip(RoundedCornerShape(6.dp))
            .background(if (isActive) c.copy(alpha = 0.15f) else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = labelSize,
            fontWeight = if (isActive || bold) FontWeight.Bold else FontWeight.Normal,
            color = c, textAlign = TextAlign.Center)
    }
}
