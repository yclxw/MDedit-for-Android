package com.mdeditor.app.util

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "md_editor_settings")

class AppSettings(private val context: Context) {

    companion object {
        val KEY_FONT_SIZE = intPreferencesKey("font_size")
        val KEY_THEME_MODE = stringPreferencesKey("theme_mode") // "light", "dark", "system"
        val KEY_AUTO_RENUMBER_LISTS = booleanPreferencesKey("auto_renumber_lists")
        val KEY_AUTO_RENUMBER_HEADINGS = booleanPreferencesKey("auto_renumber_headings")
        val KEY_USE_BLUR = booleanPreferencesKey("use_blur")
        val KEY_RECENT_FILES = stringPreferencesKey("recent_files") // JSON array
    }

    val fontSize: Flow<Int> = context.dataStore.data.map { it[KEY_FONT_SIZE] ?: 17 }
    val themeMode: Flow<String> = context.dataStore.data.map { it[KEY_THEME_MODE] ?: "system" }
    val autoRenumberLists: Flow<Boolean> = context.dataStore.data.map { it[KEY_AUTO_RENUMBER_LISTS] ?: true }
    val autoRenumberHeadings: Flow<Boolean> = context.dataStore.data.map { it[KEY_AUTO_RENUMBER_HEADINGS] ?: true }
    val useBlur: Flow<Boolean> = context.dataStore.data.map { it[KEY_USE_BLUR] ?: true }
    val recentFiles: Flow<String> = context.dataStore.data.map { it[KEY_RECENT_FILES] ?: "[]" }

    suspend fun setFontSize(size: Int) {
        context.dataStore.edit { it[KEY_FONT_SIZE] = size }
    }

    suspend fun setThemeMode(mode: String) {
        context.dataStore.edit { it[KEY_THEME_MODE] = mode }
    }

    suspend fun setAutoRenumberLists(enabled: Boolean) {
        context.dataStore.edit { it[KEY_AUTO_RENUMBER_LISTS] = enabled }
    }
    suspend fun setAutoRenumberHeadings(enabled: Boolean) {
        context.dataStore.edit { it[KEY_AUTO_RENUMBER_HEADINGS] = enabled }
    }

    suspend fun setUseBlur(enabled: Boolean) {
        context.dataStore.edit { it[KEY_USE_BLUR] = enabled }
    }

    suspend fun addRecentFile(uri: String, name: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[KEY_RECENT_FILES] ?: "[]"
            val list = parseRecentFiles(current).toMutableList()
            // Remove duplicate and add to front
            list.removeAll { it.first == uri }
            list.add(0, uri to name)
            // Keep max 20
            val trimmed = list.take(20)
            val json = trimmed.joinToString(",", "[", "]") { (u, n) ->
                """{"uri":"$u","name":"$n"}"""
            }
            prefs[KEY_RECENT_FILES] = json
        }
    }

    suspend fun clearRecentFiles() {
        context.dataStore.edit { it[KEY_RECENT_FILES] = "[]" }
    }

    private fun parseRecentFiles(json: String): List<Pair<String, String>> {
        if (json == "[]") return emptyList()
        val clean = json.removeSurrounding("[", "]")
        if (clean.isBlank()) return emptyList()
        return clean.split("},{").map { entry ->
            val cleaned = entry.removeSurrounding("{", "}")
            val uri = cleaned.substringAfter("\"uri\":\"").substringBefore("\"")
            val name = cleaned.substringAfter("\"name\":\"").substringBefore("\"")
            uri to name
        }
    }
}
