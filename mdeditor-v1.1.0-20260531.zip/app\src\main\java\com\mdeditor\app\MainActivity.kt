package com.mdeditor.app

import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher

import android.view.Gravity
import android.widget.EditText
import android.widget.Toast
import androidx.compose.ui.graphics.toArgb
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mdeditor.app.ui.components.ColorPickerDialog
import com.mdeditor.app.ui.components.FormatAction
import com.mdeditor.app.ui.components.FormatBar
import com.mdeditor.app.ui.components.MarkdownPreview
import com.mdeditor.app.ui.components.SearchReplaceBar
import com.mdeditor.app.ui.components.SearchState
import com.mdeditor.app.ui.screens.RecentFilesDialog
import com.mdeditor.app.ui.screens.SettingsDialog
import com.mdeditor.app.ui.theme.MDEditorTheme
import com.mdeditor.app.util.AppSettings
import com.mdeditor.app.util.LineParser
import com.mdeditor.app.viewmodel.EditorViewModel
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MDEditorTheme {
                var showLeftMenu by remember { mutableStateOf(false) }
                var showRightMenu by remember { mutableStateOf(false) }
                val viewModel: EditorViewModel = viewModel()
                val editorText by viewModel.editorText.collectAsState()
                val isPreviewMode by viewModel.isPreviewMode.collectAsState()
                val fileName by viewModel.currentFileName.collectAsState()
                val currentLineType by viewModel.currentLineType.collectAsState()
                val context = LocalContext.current

                val appSettings = remember { AppSettings(context) }
                val autoNumberHeadings by appSettings.autoRenumberHeadings.collectAsState(initial = true)
                LaunchedEffect(autoNumberHeadings) { viewModel.autoNumberHeadings = autoNumberHeadings }
                var showSettings by remember { mutableStateOf(false) }
                var showRecentFiles by remember { mutableStateOf(false) }
                var showAbout by remember { mutableStateOf(false) }
                var showColorPicker by remember { mutableStateOf(false) }

                var searchState by remember { mutableStateOf(SearchState()) }
                var searchMatches by remember { mutableStateOf(emptyList<Int>()) }
                var currentSearchIndex by remember { mutableStateOf(0) }

                val openLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.OpenDocument()
                ) { uri: Uri? -> uri?.let { loadFileFromUri(it, viewModel, context) } }

                val saveLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.CreateDocument("text/markdown")
                ) { uri: Uri? -> uri?.let { saveToUri(it, viewModel, context) } }

                val exportMdLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.CreateDocument("text/markdown")
                ) { uri: Uri? -> uri?.let { exportToUri(it, viewModel, context, "md") } }
                val exportTxtLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.CreateDocument("text/plain")
                ) { uri: Uri? -> uri?.let { exportToUri(it, viewModel, context, "txt") } }
                val exportHtmlLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.CreateDocument("text/html")
                ) { uri: Uri? -> uri?.let { exportToUri(it, viewModel, context, "html") } }

                // EditText ref at outer scope — accessible by both FormatBar and EditorView
                var editTextRef by remember { mutableStateOf<EditText?>(null) }

                // Format action handler — calculates line range from EditText selection
                fun handleFormatAction(action: FormatAction) {
                    val editText = editTextRef ?: return
                    val selStart = editText.selectionStart
                    val selEnd = editText.selectionEnd
                    val text = viewModel.editorText.value

                    val startLine = text.substring(0, selStart.coerceAtMost(text.length)).count { it == '\n' }
                    val endLine = if (selStart == selEnd) startLine + 1
                        else text.substring(0, selEnd.coerceAtMost(text.length)).count { it == '\n' } + 1

                    val useRange = selStart != selEnd
                    when (action) {
                        FormatAction.BODY -> {
                            if (useRange) viewModel.applyHeadingRange(startLine, endLine, 0)
                            else viewModel.applyHeading(startLine, 0)
                        }
                        FormatAction.H1 -> {
                            if (useRange) viewModel.applyHeadingRange(startLine, endLine, 1)
                            else viewModel.applyHeading(startLine, 1)
                        }
                        FormatAction.H2 -> {
                            if (useRange) viewModel.applyHeadingRange(startLine, endLine, 2)
                            else viewModel.applyHeading(startLine, 2)
                        }
                        FormatAction.H3 -> {
                            if (useRange) viewModel.applyHeadingRange(startLine, endLine, 3)
                            else viewModel.applyHeading(startLine, 3)
                        }
                        FormatAction.H4 -> {
                            if (useRange) viewModel.applyHeadingRange(startLine, endLine, 4)
                            else viewModel.applyHeading(startLine, 4)
                        }
                        FormatAction.H5 -> {
                            if (useRange) viewModel.applyHeadingRange(startLine, endLine, 5)
                            else viewModel.applyHeading(startLine, 5)
                        }
                        FormatAction.INDENT_LEFT -> {
                            if (useRange) viewModel.changeIndentRange(startLine, endLine, -1)
                            else viewModel.changeIndent(startLine, -1)
                        }
                        FormatAction.INDENT_RIGHT -> {
                            if (useRange) viewModel.changeIndentRange(startLine, endLine, 1)
                            else viewModel.changeIndent(startLine, 1)
                        }
                        FormatAction.BOLD -> {
                            val et = editTextRef ?: return@handleFormatAction
                            val ss = et.selectionStart
                            val se = et.selectionEnd
                            val txt = viewModel.editorText.value
                            if (ss < se) {
                                val selected = txt.substring(ss, se)
                                val newText = txt.substring(0, ss) + "**" + selected + "**" + txt.substring(se)
                                viewModel.updateEditorText(newText)
                            } else {
                                // Insert bold marker and place cursor between
                                val newText = txt.substring(0, ss) + "****" + txt.substring(ss)
                                viewModel.updateEditorText(newText)
                                et.post { et.setSelection(ss + 2) }
                            }
                        }
                        FormatAction.COLOR_PICKER -> {
                            showColorPicker = true
                        }
                        FormatAction.ORDERED_LIST -> {
                            if (useRange) viewModel.toggleOrderedListRange(startLine, endLine)
                            else viewModel.toggleOrderedList(startLine)
                        }
                    }
                    viewModel.clearCurrentLineType()
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        topBar = {
                            Column {
                                NavBar(
                                    title = fileName,
                                    onMenuClick = { showLeftMenu = true },
                                    onMoreClick = { showRightMenu = true }
                                )
                                FormatBar(
                                    currentLineType = currentLineType,
                                    onAction = { handleFormatAction(it) },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    ) { innerPadding ->
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                                .background(MaterialTheme.colorScheme.background)
                        ) {
                            val isDark = isSystemInDarkTheme()

                            if (isPreviewMode) {
                                MarkdownPreview(
                                    markdown = editorText,
                                    isDark = isDark,
                                    modifier = Modifier.weight(1f)
                                )
                            } else {

                                SearchReplaceBar(
                                    searchState = searchState,
                                    onFindTextChange = { text ->
                                        searchState = searchState.copy(findText = text)
                                        currentSearchIndex = 0
                                        searchMatches = if (text.isNotEmpty()) editorText.indicesOf(text) else emptyList()
                                    },
                                    onReplaceTextChange = { text ->
                                        searchState = searchState.copy(replaceText = text)
                                    },
                                    onFindNext = {
                                        if (searchMatches.isNotEmpty()) {
                                            currentSearchIndex = (currentSearchIndex + 1) % searchMatches.size
                                            editTextRef?.setSelection(
                                                searchMatches[currentSearchIndex],
                                                searchMatches[currentSearchIndex] + searchState.findText.length
                                            )
                                        }
                                    },
                                    onFindPrevious = {
                                        if (searchMatches.isNotEmpty()) {
                                            currentSearchIndex = if (currentSearchIndex == 0) searchMatches.size - 1
                                                else currentSearchIndex - 1
                                            editTextRef?.setSelection(
                                                searchMatches[currentSearchIndex],
                                                searchMatches[currentSearchIndex] + searchState.findText.length
                                            )
                                        }
                                    },
                                    onReplace = {
                                        if (searchMatches.isNotEmpty() && searchState.replaceText.isNotEmpty()) {
                                            val idx = searchMatches[currentSearchIndex]
                                            val before = editorText.substring(0, idx)
                                            val after = editorText.substring(idx + searchState.findText.length)
                                            val newText = before + searchState.replaceText + after
                                            viewModel.updateEditorText(newText)
                                            searchMatches = newText.indicesOf(searchState.findText)
                                        }
                                    },
                                    onReplaceAll = {
                                        if (searchState.findText.isNotEmpty()) {
                                            viewModel.updateEditorText(
                                                editorText.replace(searchState.findText, searchState.replaceText)
                                            )
                                            searchMatches = emptyList()
                                        }
                                    },
                                    onClose = {
                                        searchState = SearchState()
                                        searchMatches = emptyList()
                                    },
                                    matchCount = searchMatches.size,
                                    currentMatch = if (searchMatches.isEmpty()) 0 else currentSearchIndex + 1
                                )

                                EditorView(
                                    text = editorText,
                                    onTextChange = { viewModel.updateEditorText(it) },
                                    onCursorChange = { lineIndex -> viewModel.updateCurrentLineType(lineIndex) },
                                    onEnterPressed = { viewModel.getAutoNumberText(it) },
                                    editTextRef = { editTextRef = it },
                                    showLineNumbers = viewModel.showLineNumbers.collectAsState().value,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                // Left dropdown — zero-height overlay at top-left
                Row(Modifier.fillMaxWidth().height(0.dp), horizontalArrangement = Arrangement.Start) {
                    LeftDropdownMenu(
                        expanded = showLeftMenu,
                        onDismiss = { showLeftMenu = false },
                        onItemClick = { item ->
                            when (item) {
                                "new_md" -> { viewModel.resetState(); showToast(context, "新建 MD 文档") }
                                "open" -> openLauncher.launch(arrayOf("text/*"))
                                "save" -> {
                                    val uri = viewModel.currentFileUri.value
                                    if (uri != null) saveToUri(uri, viewModel, context)
                                    else saveLauncher.launch("untitled.md")
                                }
                                "close" -> { viewModel.resetState(); showToast(context, "已关闭") }
                                "settings" -> showSettings = true
                                "recent" -> showRecentFiles = true
                                "about" -> showAbout = true
                                else -> handleDrawerExport(item, exportMdLauncher, exportTxtLauncher, exportHtmlLauncher)
                            }
                        }
                    )
                }

                // Right dropdown — zero-height overlay at top-right
                Row(Modifier.fillMaxWidth().height(0.dp), horizontalArrangement = Arrangement.End) {
                    RightDropdownMenu(
                        expanded = showRightMenu,
                        onDismiss = { showRightMenu = false },
                        onItemClick = { item ->
                            when (item) {
                                "edit_mode" -> viewModel.setPreviewMode(false)
                                "preview_mode" -> viewModel.setPreviewMode(true)
                                "find_replace" -> searchState = SearchState(visible = true)
                                else -> handleMenuAction(item, viewModel, context, editTextRef)
                            }
                        }
                    )
                }
            } // Box

                // --- Dialogs ---
                if (showSettings) {
                    SettingsDialog(
                        settings = appSettings,
                        onDismiss = { showSettings = false },
                        onThemeChanged = { }
                    )
                }
                if (showRecentFiles) {
                    val recentJson by appSettings.recentFiles.collectAsState(initial = "[]")
                    val recentList = remember(recentJson) { parseRecentJson(recentJson) }
                    RecentFilesDialog(
                        files = recentList,
                        onFileClick = { uri ->
                            showRecentFiles = false
                            try {
                                loadFileFromUri(Uri.parse(uri), viewModel, context)
                            } catch (_: Exception) {
                                showToast(context, "文件不存在或无权限访问")
                            }
                        },
                        onDismiss = { showRecentFiles = false }
                    )
                }
                if (showAbout) {
                    AlertDialog(
                        onDismissRequest = { showAbout = false },
                        title = { Text("关于 MD编辑器") },
                        text = {
                            Text(
                                "版本：v1.1.0\n作者：帅气的锅巴"
                            )
                        },
                        confirmButton = {
                            TextButton(onClick = { showAbout = false }) { Text("确定") }
                        }
                    )
                }

                if (showColorPicker) {
                    ColorPickerDialog(
                        onColorSelected = { color ->
                            showColorPicker = false
                            val et = editTextRef ?: return@ColorPickerDialog
                            val ss = et.selectionStart
                            val se = et.selectionEnd
                            if (ss < se) {
                                val hex = String.format("%06X", color.toArgb() and 0xFFFFFF)
                                val txt = viewModel.editorText.value
                                val selected = txt.substring(ss, se)
                                val newText = txt.substring(0, ss) + "[c=#$hex]$selected[/c]" + txt.substring(se)
                                viewModel.updateEditorText(newText)
                                et.post { et.setSelection(ss + "[c=#$hex]".length + selected.length + "[/c]".length) }
                            }
                        },
                        onDismiss = { showColorPicker = false }
                    )
                }
            }
        }
    }
}

// --- Extension ---

private fun parseRecentJson(json: String): List<Pair<String, String>> {
    if (json == "[]" || json.isBlank()) return emptyList()
    val clean = json.removeSurrounding("[", "]")
    if (clean.isBlank()) return emptyList()
    return clean.split("},{").map { entry ->
        val cleaned = entry.removeSurrounding("{", "}")
        val uri = cleaned.substringAfter("\"uri\":\"").substringBefore("\"")
        val name = cleaned.substringAfter("\"name\":\"").substringBefore("\"")
        uri to name
    }
}

// --- Editor View ---

@Composable
fun EditorView(
    text: String,
    onTextChange: (String) -> Unit,
    onCursorChange: (Int) -> Unit,
    onEnterPressed: (String) -> String?,
    editTextRef: (EditText) -> Unit,
    showLineNumbers: Boolean = false,
    modifier: Modifier = Modifier
) {
    val isUpdating = remember { AtomicBoolean(false) }
    val textWatchersSet = remember { AtomicBoolean(false) }
    val lineCount = remember(text) { text.lines().size.coerceAtLeast(1) }

    Row(modifier = modifier) {
        // Line number gutter
        if (showLineNumbers) {
            val lineNumbers = remember(text) {
                (1..lineCount).joinToString("\n")
            }
            Text(
                text = lineNumbers,
                modifier = Modifier
                    .width(40.dp)
                    .padding(top = 8.dp)
                    .wrapContentHeight(),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.secondary
            )
        }

        AndroidView(
            modifier = Modifier.weight(1f).padding(start = 0.dp, top = 8.dp, end = 16.dp, bottom = 8.dp),
            factory = { ctx ->
                EditText(ctx).apply {
                gravity = Gravity.TOP or Gravity.START
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                setTextSize(17f)
                setPadding(8, 8, 8, 8)
                setHorizontallyScrolling(false)
                isVerticalScrollBarEnabled = true
                isVerticalFadingEdgeEnabled = false
                overScrollMode = android.view.View.OVER_SCROLL_ALWAYS
                isCursorVisible = true
                setSelectAllOnFocus(true)
                if (text.isNotEmpty()) setText(text)
                requestFocus()
                post { requestFocus() }
                editTextRef(this)
            }
        },
        update = { editText ->
            if (!textWatchersSet.getAndSet(true)) {
                editText.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        if (isUpdating.get()) return
                        val newText = s?.toString() ?: ""
                        if (newText != text) {
                            isUpdating.set(true)
                            onTextChange(newText)
                            isUpdating.set(false)
                        }
                        val cursorPos = editText.selectionStart
                        val textBeforeCursor = newText.substring(0, cursorPos.coerceAtMost(newText.length))
                        val lineIndex = textBeforeCursor.count { it == '\n' }
                        onCursorChange(lineIndex)
                    }
                })

                var lastText = editText.text.toString()
                editText.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        if (isUpdating.get()) return
                        val newText = s?.toString() ?: ""
                        if (newText.length > lastText.length && newText.contains("\n")) {
                            val cursorPos = editText.selectionStart
                            if (cursorPos > 0 && newText.getOrNull(cursorPos - 1) == '\n') {
                                val textBeforeNewline = newText.substring(0, cursorPos - 1)
                                val prevLine = textBeforeNewline.substringAfterLast('\n')
                                val autoText = onEnterPressed(prevLine)
                                if (autoText != null) {
                                    isUpdating.set(true)
                                    val before = newText.substring(0, cursorPos)
                                    val after = newText.substring(cursorPos)
                                    editText.setText(before + autoText + after)
                                    editText.setSelection(cursorPos + autoText.length)
                                    isUpdating.set(false)
                                }
                            }
                        }
                        lastText = editText.text.toString()
                    }
                })
            }

            if (isUpdating.get()) return@AndroidView
            if (editText.text.toString() != text) {
                isUpdating.set(true)
                val cursor = editText.selectionStart.coerceAtMost(text.length)
                editText.setText(text)
                editText.setSelection(cursor)
                isUpdating.set(false)
            }
        }
        ) // AndroidView
    } // Row
}

// --- NavBar ---

@Composable
fun NavBar(title: String, onMenuClick: () -> Unit, onMoreClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().statusBarsPadding().height(44.dp),
        color = MaterialTheme.colorScheme.surface
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TextButton(onClick = onMenuClick, contentPadding = PaddingValues(8.dp)) {
                Text("☰", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            }
            Text(
                title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            TextButton(onClick = onMoreClick, contentPadding = PaddingValues(8.dp)) {
                Text("⋮", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

// --- Left Dropdown ---

@Composable
fun LeftDropdownMenu(expanded: Boolean, onDismiss: () -> Unit, onItemClick: (String) -> Unit) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(
            text = { Text("📝  新建 MD 文档") },
            onClick = { onItemClick("new_md"); onDismiss() }
        )
        DropdownMenuItem(
            text = { Text("📂  打开文档") },
            onClick = { onItemClick("open"); onDismiss() }
        )
        DropdownMenuItem(
            text = { Text("💾  保存") },
            onClick = { onItemClick("save"); onDismiss() }
        )
        DropdownMenuItem(
            text = { Text("✕  关闭") },
            onClick = { onItemClick("close"); onDismiss() }
        )
        DropdownMenuItem(
            text = { Text("🕐  最近打开") },
            onClick = { onItemClick("recent"); onDismiss() }
        )
        Divider()
        DropdownMenuItem(
            text = { Text("📝  导出 Markdown") },
            onClick = { onItemClick("export_md"); onDismiss() }
        )
        DropdownMenuItem(
            text = { Text("📃  导出 TXT") },
            onClick = { onItemClick("export_txt"); onDismiss() }
        )
        DropdownMenuItem(
            text = { Text("🌐  导出 HTML") },
            onClick = { onItemClick("export_html"); onDismiss() }
        )
        Divider()
        DropdownMenuItem(
            text = { Text("⚙️  应用设置") },
            onClick = { onItemClick("settings"); onDismiss() }
        )
        DropdownMenuItem(
            text = { Text("ℹ️  关于") },
            onClick = { onItemClick("about"); onDismiss() }
        )
    }
}

// --- Right Dropdown ---

@Composable
fun RightDropdownMenu(expanded: Boolean, onDismiss: () -> Unit, onItemClick: (String) -> Unit) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(
            text = { Text("✏️  编辑模式") },
            onClick = { onItemClick("edit_mode"); onDismiss() }
        )
        DropdownMenuItem(
            text = { Text("👁️  预览模式") },
            onClick = { onItemClick("preview_mode"); onDismiss() }
        )
        Divider()
        DropdownMenuItem(
            text = { Text("🔍 查找与替换") },
            onClick = { onItemClick("find_replace"); onDismiss() }
        )
        DropdownMenuItem(
            text = { Text("📊 字数统计") },
            onClick = { onItemClick("word_count"); onDismiss() }
        )
        Divider()
        DropdownMenuItem(
            text = { Text("📋 全选") },
            onClick = { onItemClick("select_all"); onDismiss() }
        )
        DropdownMenuItem(
            text = { Text("✂️ 剪切") },
            onClick = { onItemClick("cut"); onDismiss() }
        )
        DropdownMenuItem(
            text = { Text("📋 复制") },
            onClick = { onItemClick("copy"); onDismiss() }
        )
        DropdownMenuItem(
            text = { Text("📋 粘贴") },
            onClick = { onItemClick("paste"); onDismiss() }
        )
        Divider()
        DropdownMenuItem(
            text = { Text("🔢 重新编号") },
            onClick = { onItemClick("renumber"); onDismiss() }
        )
        DropdownMenuItem(
            text = { Text("📝 显示/隐藏行号") },
            onClick = { onItemClick("toggle_line_numbers"); onDismiss() }
        )
    }
}

// --- Handlers ---

private fun handleMenuAction(
    item: String,
    viewModel: EditorViewModel,
    context: android.content.Context,
    editText: EditText?
) {
    when (item) {
        "word_count" -> {
            val wc = viewModel.getWordCount()
            showToast(context, "字符: ${wc.charsWithSpaces} | 单词: ${wc.words} | 行数: ${wc.lines}")
        }
        "select_all" -> editText?.selectAll()
        "cut" -> {
            val et = editText ?: return
            val ss = et.selectionStart
            val se = et.selectionEnd
            if (ss != se) {
                val text = viewModel.editorText.value
                val selected = text.substring(
                    ss.coerceAtMost(text.length), se.coerceAtMost(text.length))
                val clip = android.content.ClipData.newPlainText("md", selected)
                (context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager)
                    ?.setPrimaryClip(clip)
                viewModel.updateEditorText(text.substring(0, ss) + text.substring(se))
            }
        }
        "copy" -> {
            val clip = android.content.ClipData.newPlainText("md", viewModel.editorText.value)
            (context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager)
                ?.setPrimaryClip(clip)
        }
        "paste" -> {
            val clip = (context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager)
                ?.primaryClip?.getItemAt(0)?.text?.toString()
            clip?.let { editText?.text?.insert(editText.selectionStart, it) }
        }
        "renumber" -> {
            viewModel.renumberAllHeadings()
            viewModel.renumberAllLists()
        }
        "toggle_line_numbers" -> viewModel.toggleLineNumbers()
    }
}

private fun handleDrawerExport(
    item: String,
    exportMdLauncher: androidx.activity.result.ActivityResultLauncher<String>,
    exportTxtLauncher: androidx.activity.result.ActivityResultLauncher<String>,
    exportHtmlLauncher: androidx.activity.result.ActivityResultLauncher<String>
) {
    when (item) {
        "export_md" -> exportMdLauncher.launch("export.md")
        "export_txt" -> exportTxtLauncher.launch("export.txt")
        "export_html" -> exportHtmlLauncher.launch("export.html")
    }
}

// --- File I/O ---

private fun loadFileFromUri(uri: Uri, viewModel: EditorViewModel, context: android.content.Context) {
    try {
        val content = context.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: ""
        viewModel.setEditorText(content)
        viewModel.setCurrentFile(uri, uri.lastPathSegment ?: "untitled.md")
        viewModel.markSaved()
        showToast(context, "文件已打开")
    } catch (e: Exception) {
        showToast(context, "打开文件失败: ${e.message}")
    }
}

private fun saveToUri(uri: Uri, viewModel: EditorViewModel, context: android.content.Context) {
    try {
        context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { writer ->
            writer.write(viewModel.editorText.value)
        }
        viewModel.setCurrentFile(uri, uri.lastPathSegment ?: "untitled.md")
        viewModel.markSaved()
        showToast(context, "已保存")
    } catch (e: Exception) {
        showToast(context, "保存失败: ${e.message}")
    }
}

private fun exportToUri(uri: Uri, viewModel: EditorViewModel, context: android.content.Context, format: String) {
    try {
        val content = when (format) {
            "md" -> viewModel.editorText.value
            "txt" -> viewModel.editorText.value.lines().joinToString("\n") { LineParser.getContent(it) }
            "html" -> {
                val text = viewModel.editorText.value
                "<html><body><pre>${text.replace("<", "&lt;").replace(">", "&gt;")}</pre></body></html>"
            }
            else -> viewModel.editorText.value
        }
        context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(content) }
        showToast(context, "导出成功 ($format)")
    } catch (e: Exception) {
        showToast(context, "导出失败: ${e.message}")
    }
}

private fun showToast(context: android.content.Context, message: String) {
    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
}

private fun String.indicesOf(substring: String): List<Int> {
    val indices = mutableListOf<Int>()
    var start = 0
    while (start < length) {
        val idx = indexOf(substring, start)
        if (idx == -1) break
        indices.add(idx)
        start = idx + 1
    }
    return indices
}
