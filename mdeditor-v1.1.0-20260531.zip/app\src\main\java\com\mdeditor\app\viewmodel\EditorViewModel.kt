package com.mdeditor.app.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import com.mdeditor.app.util.LineParser
import com.mdeditor.app.util.LineParser.LineType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class EditorViewModel : ViewModel() {

    /** Controlled by AppSettings.autoRenumberHeadings — set from MainActivity. */
    var autoNumberHeadings: Boolean = true

    private val _editorText = MutableStateFlow("")
    val editorText: StateFlow<String> = _editorText.asStateFlow()

    private val _currentFileUri = MutableStateFlow<Uri?>(null)
    val currentFileUri: StateFlow<Uri?> = _currentFileUri.asStateFlow()

    private val _currentFileName = MutableStateFlow("MD编辑器")
    val currentFileName: StateFlow<String> = _currentFileName.asStateFlow()

    private val _isModified = MutableStateFlow(false)
    val isModified: StateFlow<Boolean> = _isModified.asStateFlow()

    private val _isPreviewMode = MutableStateFlow(false)
    val isPreviewMode: StateFlow<Boolean> = _isPreviewMode.asStateFlow()

    private val _showLineNumbers = MutableStateFlow(false)
    val showLineNumbers: StateFlow<Boolean> = _showLineNumbers.asStateFlow()

    private val _currentLineType = MutableStateFlow(LineType.BODY)
    val currentLineType: StateFlow<LineType> = _currentLineType.asStateFlow()

    fun setEditorText(text: String) { _editorText.value = text }
    fun updateEditorText(text: String) { _editorText.value = text; _isModified.value = true }
    fun setCurrentFile(uri: Uri?, name: String) { _currentFileUri.value = uri; _currentFileName.value = name }
    fun markSaved() { _isModified.value = false }
    fun togglePreview() { _isPreviewMode.value = !_isPreviewMode.value }
    fun setPreviewMode(preview: Boolean) { _isPreviewMode.value = preview }
    fun toggleLineNumbers() { _showLineNumbers.value = !_showLineNumbers.value }
    fun resetState() {
        _editorText.value = ""; _currentFileUri.value = null
        _currentFileName.value = "MD编辑器"; _isModified.value = false; _isPreviewMode.value = false
    }
    fun updateCurrentLineType(cursorLine: Int) {
        val ls = _editorText.value.lines()
        if (cursorLine in ls.indices) _currentLineType.value = LineParser.parse(ls[cursorLine])
    }
    fun clearCurrentLineType() { _currentLineType.value = LineType.BODY }

    // --- helpers ---

    private fun lines(): List<String> = _editorText.value.lines()

    private fun applyText(newText: String) { _editorText.value = newText; _isModified.value = true }

    // ===================================================================
    //  Hierarchical heading auto-numbering
    // ===================================================================

    /**
     * Scan all lines, assign hierarchical numbers to headings:
     *   H1 → 1., 2., 3., ...
     *   H2 under H1 "2." → 2.1., 2.2., ...
     *   H3 under H2 "2.1." → 2.1.1., 2.1.2., ...
     *   H4, H5 follow the same pattern.
     */
    fun renumberAllHeadings() {
        if (!autoNumberHeadings) return
        val all = _editorText.value.lines().toMutableList()
        val counters = IntArray(5) // [H1, H2, H3, H4, H5]

        for (i in all.indices) {
            val line = all[i]
            val level = LineParser.getHeadingLevel(line)
            if (level in 1..5) {
                // Increment this level's counter
                counters[level - 1]++
                // Reset all lower-level counters
                for (j in level until 5) counters[j] = 0
                // Build number prefix
                val numStr = LineParser.buildHeadingNumber(counters)
                // Get content WITHOUT any existing number prefix
                var content = LineParser.getContent(line)
                // Strip any existing hierarchical number (e.g. "1.2. " prefix)
                content = content.replaceFirst(Regex("""^(\d+\.)*\s*"""), "")
                all[i] = LineParser.headingPrefix(level) + numStr + " " + content
            }
        }
        _editorText.value = all.joinToString("\n")
        _isModified.value = true
    }

    // ===================================================================
    //  Heading operations
    // ===================================================================

    fun applyHeading(lineIndex: Int, level: Int) {
        val all = lines()
        if (lineIndex !in all.indices) return
        val line = all[lineIndex]
        if (LineParser.getHeadingLevel(line) == level) {
            // Toggle off: strip heading marker + number prefix
            var content = LineParser.getContent(line)
            content = content.replaceFirst(Regex("""^(\d+\.)*\s*"""), "")
            setLine(lineIndex, content)
        } else {
            setLine(lineIndex, LineParser.headingPrefix(level) + LineParser.getContent(line))
        }
        if (autoNumberHeadings) renumberAllHeadings()
    }

    fun applyHeadingRange(startLine: Int, endLine: Int, level: Int) {
        val all = lines().toMutableList()
        val rangeEnd = endLine.coerceAtMost(all.size)
        for (i in startLine until rangeEnd) {
            var content = LineParser.getContent(all[i])
            content = content.replaceFirst(Regex("""^(\d+\.)*\s*"""), "")
            all[i] = LineParser.headingPrefix(level) + content
        }
        _editorText.value = all.joinToString("\n")
        _isModified.value = true
        applyHeadingRangeRenumber()
    }

    private fun applyHeadingRangeRenumber() {
        if (autoNumberHeadings) renumberAllHeadings()
    }

    fun changeHeadingLevel(lineIndex: Int, delta: Int) {
        val all = lines()
        if (lineIndex !in all.indices) return
        val line = all[lineIndex]
        val cur = LineParser.getHeadingLevel(line)
        if (cur in 1..5) {
            val new = (cur + delta).coerceIn(1, 5)
            var content = LineParser.getContent(line)
            content = content.replaceFirst(Regex("""^(\d+\.)*\s*"""), "")
            setLine(lineIndex, LineParser.headingPrefix(new) + content)
        } else if (delta > 0) {
            setLine(lineIndex, "# " + line)
        }
        if (autoNumberHeadings) renumberAllHeadings()
    }

    fun changeHeadingLevelRange(startLine: Int, endLine: Int, delta: Int) {
        val all = lines().toMutableList()
        val rangeEnd = endLine.coerceAtMost(all.size)
        for (i in startLine until rangeEnd) {
            val cur = LineParser.getHeadingLevel(all[i])
            if (cur in 1..5) {
                val new = (cur + delta).coerceIn(1, 5)
                var content = LineParser.getContent(all[i])
                content = content.replaceFirst(Regex("""^(\d+\.)*\s*"""), "")
                all[i] = LineParser.headingPrefix(new) + content
            } else if (delta > 0) {
                all[i] = "# " + all[i]
            }
        }
        _editorText.value = all.joinToString("\n")
        _isModified.value = true
        if (autoNumberHeadings) renumberAllHeadings()
    }

    // ===================================================================
    //  Ordered list operations
    // ===================================================================

    fun toggleOrderedList(lineIndex: Int) {
        val all = lines()
        if (lineIndex !in all.indices) return
        val line = all[lineIndex]
        if (LineParser.parse(line) == LineType.ORDERED_LIST) {
            val indent = LineParser.getIndentSpaces(line)
            val content = LineParser.getContent(line)
            setLine(lineIndex, if (indent > 0) " ".repeat(indent) + content else content)
        } else {
            setLine(lineIndex, "1. " + LineParser.getContent(line))
        }
    }

    fun toggleOrderedListRange(startLine: Int, endLine: Int) {
        val all = lines().toMutableList()
        val rangeEnd = endLine.coerceAtMost(all.size)
        var counter = 1
        for (i in startLine until rangeEnd) {
            val line = all[i]
            if (LineParser.parse(line) == LineType.ORDERED_LIST) {
                val indent = LineParser.getIndentSpaces(line)
                val content = LineParser.getContent(line)
                all[i] = if (indent > 0) " ".repeat(indent) + content else content
            } else {
                all[i] = "$counter. " + LineParser.getContent(line)
                counter++
            }
        }
        _editorText.value = all.joinToString("\n")
        _isModified.value = true
    }

    fun changeIndent(lineIndex: Int, delta: Int) {
        val all = lines()
        if (lineIndex !in all.indices) return
        val line = all[lineIndex]
        val type = LineParser.parse(line)
        when {
            type == LineType.ORDERED_LIST -> {
                val cur = LineParser.getIndentSpaces(line)
                val new = (cur + delta * 2).coerceIn(0, 6)
                setLine(lineIndex, LineParser.listPrefix(new, LineParser.getListNumber(line)) + LineParser.getContent(line))
            }
            LineParser.isHeading(type) -> changeHeadingLevel(lineIndex, delta)
            delta > 0 -> setLine(lineIndex, "# $line")
        }
    }

    fun changeIndentRange(startLine: Int, endLine: Int, delta: Int) {
        val all = lines().toMutableList()
        val rangeEnd = endLine.coerceAtMost(all.size)
        for (i in startLine until rangeEnd) {
            val line = all[i]
            val type = LineParser.parse(line)
            when {
                type == LineType.ORDERED_LIST -> {
                    val cur = LineParser.getIndentSpaces(line)
                    val new = (cur + delta * 2).coerceIn(0, 6)
                    all[i] = LineParser.listPrefix(new, LineParser.getListNumber(line)) + LineParser.getContent(line)
                }
                LineParser.isHeading(type) -> {
                    val cur = LineParser.getHeadingLevel(line)
                    val new = (cur + delta).coerceIn(1, 5)
                    var content = LineParser.getContent(line)
                    content = content.replaceFirst(Regex("""^(\d+\.)*\s*"""), "")
                    all[i] = LineParser.headingPrefix(new) + content
                }
                delta > 0 -> all[i] = "# $line"
            }
        }
        _editorText.value = all.joinToString("\n")
        _isModified.value = true
        if (autoNumberHeadings) renumberAllHeadings()
    }

    // ===================================================================
    //  Auto-numbering on Enter
    // ===================================================================

    fun getAutoNumberText(prevLine: String): String? {
        if (LineParser.parse(prevLine) != LineType.ORDERED_LIST) return null
        val content = LineParser.getContent(prevLine)
        if (content.isBlank()) return null
        val indent = LineParser.getIndentSpaces(prevLine)
        val number = LineParser.getListNumber(prevLine)
        return LineParser.listPrefix(indent, number + 1)
    }

    // ===================================================================
    //  Renumber all lists
    // ===================================================================

    fun renumberAllLists() {
        val lines = _editorText.value.lines().toMutableList()
        // Global counter per indent level — lists get continuous numbering
        val counters = mutableMapOf<Int, Int>()

        for (i in lines.indices) {
            if (LineParser.parse(lines[i]) == LineType.ORDERED_LIST) {
                val indent = LineParser.getIndentSpaces(lines[i])
                val num = counters.getOrDefault(indent, 0) + 1
                counters[indent] = num
                lines[i] = LineParser.listPrefix(indent, num) + LineParser.getContent(lines[i])
            } else {
                // Non-list line resets counters for all indent levels
                counters.clear()
            }
        }
        _editorText.value = lines.joinToString("\n")
        _isModified.value = true
    }

    // ===================================================================
    //  Word count
    // ===================================================================

    data class WordCount(val charsWithSpaces: Int, val charsWithoutSpaces: Int, val words: Int, val lines: Int)

    fun getWordCount(): WordCount {
        val text = _editorText.value
        val ls = text.lines()
        return WordCount(
            charsWithSpaces = text.length,
            charsWithoutSpaces = text.count { !it.isWhitespace() },
            words = if (text.isBlank()) 0 else text.trim().split("\\s+".toRegex()).size,
            lines = ls.size
        )
    }

    private fun setLine(index: Int, newLine: String) {
        val all = _editorText.value.lines().toMutableList()
        if (index in all.indices) { all[index] = newLine; _editorText.value = all.joinToString("\n"); _isModified.value = true }
    }
}
