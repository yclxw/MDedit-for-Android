package com.mdeditor.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.mdeditor.app.ui.theme.ButtonActive

// iOS common colors
data class IosColor(val name: String, val color: Color, val hex: String)

val iosColors = listOf(
    IosColor("红色", Color(0xFFFF3B30), "#FF3B30"),
    IosColor("橙色", Color(0xFFFF9500), "#FF9500"),
    IosColor("黄色", Color(0xFFFFCC00), "#FFCC00"),
    IosColor("绿色", Color(0xFF34C759), "#34C759"),
    IosColor("薄荷", Color(0xFF00C7BE), "#00C7BE"),
    IosColor("青色", Color(0xFF32ADE6), "#32ADE6"),
    IosColor("蓝色", Color(0xFF007AFF), "#007AFF"),
    IosColor("靛蓝", Color(0xFF5856D6), "#5856D6"),
    IosColor("紫色", Color(0xFFAF52DE), "#AF52DE"),
    IosColor("粉色", Color(0xFFFF2D55), "#FF2D55"),
    IosColor("棕色", Color(0xFFA2845E), "#A2845E"),
    IosColor("黑色", Color(0xFF1C1C1E), "#1C1C1E"),
    IosColor("灰色", Color(0xFF8E8E93), "#8E8E93"),
    IosColor("白色", Color(0xFFFFFFFF), "#FFFFFF"),
    IosColor("深灰", Color(0xFF48484A), "#48484A"),
    IosColor("浅灰", Color(0xFFC7C7CC), "#C7C7CC"),
    IosColor("金色", Color(0xFFFFD60A), "#FFD60A"),
    IosColor("深绿", Color(0xFF248A3D), "#248A3D"),
    IosColor("桃红", Color(0xFFFF375F), "#FF375F"),
    IosColor("天蓝", Color(0xFF64D2FF), "#64D2FF"),
)

// Quick access colors shown in the format bar
val quickColors = listOf(
    Color(0xFFFF3B30), // red
    Color(0xFFFF9500), // orange
    Color(0xFF34C759), // green
    Color(0xFF007AFF), // blue
    Color(0xFF5856D6), // indigo
    Color(0xFFAF52DE), // purple
    Color(0xFFFF2D55), // pink
    Color(0xFF1C1C1E), // black
)

@Composable
fun ColorPickerDialog(
    onColorSelected: (Color) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedColor by remember { mutableStateOf(Color(0xFF007AFF)) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 80.dp),
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Header
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("取消", color = MaterialTheme.colorScheme.secondary)
                    }
                    Text("选择颜色", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    TextButton(onClick = { onColorSelected(selectedColor); onDismiss() }) {
                        Text("确定", color = ButtonActive, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(Modifier.height(12.dp))

                // Color preview
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(selectedColor)
                )

                Spacer(Modifier.height(16.dp))

                // Color grid
                LazyVerticalGrid(
                    columns = GridCells.Fixed(5),
                    modifier = Modifier.height(320.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(iosColors) { item ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.clickable { selectedColor = item.color }
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(item.color)
                                    .then(
                                        if (selectedColor == item.color)
                                            Modifier.border(3.dp, MaterialTheme.colorScheme.primary, CircleShape)
                                        else Modifier
                                    )
                            )
                            Text(
                                item.name,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))

                // Hex display
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    val hex = iosColors.find { it.color == selectedColor }?.hex
                        ?: String.format("#%06X", (0xFFFFFF and selectedColor.hashCode()))
                    Text(hex, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.secondary)
                }
            }
        }
    }
}
