package com.mdeditor.app.util

object LineParser {

    enum class LineType { BODY, HEADING_1, HEADING_2, HEADING_3, HEADING_4, HEADING_5, ORDERED_LIST }

    private val headingRegex = Regex("""^(#{1,5})(?:\s+(.*))?$""")
    private val listRegex = Regex("""^(\s*)(\d+)\.\s+(.*)$""")

    fun parse(line: String): LineType {
        val trimmed = line.trimStart()
        if (trimmed.isEmpty()) return LineType.BODY
        if (listRegex.matches(line)) return LineType.ORDERED_LIST
        val m = headingRegex.find(trimmed) ?: return LineType.BODY
        return when (m.groupValues[1].length) {
            1 -> LineType.HEADING_1; 2 -> LineType.HEADING_2; 3 -> LineType.HEADING_3
            4 -> LineType.HEADING_4; 5 -> LineType.HEADING_5; else -> LineType.BODY
        }
    }

    fun isHeading(type: LineType): Boolean = type.name.startsWith("HEADING")

    fun getContent(line: String): String {
        return when (parse(line)) {
            LineType.BODY -> line
            LineType.ORDERED_LIST -> listRegex.find(line)?.groupValues?.getOrNull(3) ?: line
            else -> headingRegex.find(line.trimStart())?.groupValues?.getOrNull(2) ?: ""
        }
    }

    fun getIndentSpaces(line: String): Int = listRegex.find(line)?.groupValues?.get(1)?.length ?: 0

    fun getHeadingLevel(line: String): Int {
        val m = headingRegex.find(line.trimStart()) ?: return 0
        return m.groupValues[1].length
    }

    fun getListNumber(line: String): Int =
        listRegex.find(line)?.groupValues?.get(2)?.toIntOrNull() ?: 1

    fun headingPrefix(level: Int): String = "#".repeat(level) + " "
    fun listPrefix(indentSpaces: Int, number: Int): String =
        " ".repeat(indentSpaces) + "$number. "

    /** Build hierarchical number string: e.g. "1.", "1.2.", "3.1.4." */
    fun buildHeadingNumber(counters: IntArray): String {
        val sb = StringBuilder()
        for (i in counters.indices) {
            if (counters[i] == 0) break
            sb.append(counters[i]).append('.')
        }
        return sb.toString()
    }
}
