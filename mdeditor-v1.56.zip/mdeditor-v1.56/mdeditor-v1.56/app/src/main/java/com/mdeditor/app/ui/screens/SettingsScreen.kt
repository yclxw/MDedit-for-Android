package com.mdeditor.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.mdeditor.app.ui.theme.ButtonActive
import com.mdeditor.app.util.AppSettings
import kotlinx.coroutines.launch

@Composable
fun SettingsDialog(
    settings: AppSettings,
    onDismiss: () -> Unit,
    onThemeChanged: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val fontSize by settings.fontSize.collectAsState(initial = 17)
    val themeMode by settings.themeMode.collectAsState(initial = "system")
    val autoRenumberHeadings by settings.autoRenumberHeadings.collectAsState(initial = true)
    val useBlur by settings.useBlur.collectAsState(initial = true)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .padding(top = 48.dp),
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "设置",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = onDismiss) {
                        Text("完成", color = ButtonActive)
                    }
                }

                Divider()

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    // Font size
                    item {
                        SettingsGroup("字体大小") {
                            Column {
                                Text(
                                    "编辑器正文字号: ${fontSize}sp",
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                Slider(
                                    value = fontSize.toFloat(),
                                    onValueChange = {
                                        scope.launch { settings.setFontSize(it.toInt()) }
                                    },
                                    valueRange = 14f..22f,
                                    steps = 7,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }

                    // Theme
                    item {
                        SettingsGroup("主题") {
                            val options = listOf(
                                "light" to "浅色",
                                "dark" to "深色",
                                "system" to "跟随系统"
                            )
                            options.forEach { (value, label) ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable {
                                            scope.launch {
                                                settings.setThemeMode(value)
                                                onThemeChanged()
                                            }
                                        }
                                        .padding(vertical = 10.dp, horizontal = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(label, style = MaterialTheme.typography.bodyLarge)
                                    if (themeMode == value) {
                                        Text("✓", color = ButtonActive, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    // Auto renumber — headings only
                    item {
                        SettingsGroup("自动编号") {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("标题自动编号", style = MaterialTheme.typography.bodyLarge)
                                Switch(
                                    checked = autoRenumberHeadings,
                                    onCheckedChange = { scope.launch { settings.setAutoRenumberHeadings(it) } }
                                )
                            }
                        }
                    }

                    // Blur effect
                    item {
                        SettingsGroup("毛玻璃效果") {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "菜单背景模糊",
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                Switch(
                                    checked = useBlur,
                                    onCheckedChange = {
                                        scope.launch { settings.setUseBlur(it) }
                                    }
                                )
                            }
                            Text(
                                "API 31+ 有效，低版本自动降级为半透明遮罩",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }

                    // Export path info
                    item {
                        SettingsGroup("默认保存路径") {
                            Text(
                                "由系统文件选择器 (SAF) 管理，应用不直接请求文件系统权限",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }

                    // About
                    item {
                        SettingsGroup("关于") {
                            Text(
                                "版本：v1.56",
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Text(
                                "作者：帅气的锅巴",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RecentFilesDialog(
    files: List<Pair<String, String>>,
    onFileClick: (String) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier.fillMaxHeight(),
            contentAlignment = Alignment.TopCenter
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 8.dp
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "日志",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        TextButton(onClick = onDismiss) {
                            Text("关闭", color = ButtonActive)
                        }
                    }

                    if (files.isEmpty()) {
                        Text(
                            "暂无最近文件",
                            color = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.padding(vertical = 16.dp)
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.heightIn(max = 240.dp),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            items(files) { (uri, name) ->
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 1.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .clickable { onFileClick(uri) },
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                                ) {
                                    Text(
                                        text = name,
                                        style = MaterialTheme.typography.bodyMedium,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            content()
        }
    }
}
