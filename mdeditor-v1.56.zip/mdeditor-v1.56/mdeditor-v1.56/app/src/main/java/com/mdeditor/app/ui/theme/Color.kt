package com.mdeditor.app.ui.theme

import androidx.compose.ui.graphics.Color

// Light theme colors — iOS-inspired
val LightBackground = Color(0xFFF2F2F7)
val LightSurface = Color(0xFFFFFFFF)
val LightOnBackground = Color(0xFF000000)
val LightOnSurface = Color(0xFF1C1C1E)
val LightPrimary = Color(0xFF007AFF)
val LightSecondary = Color(0xFF8E8E93)
val LightSeparator = Color(0xFFC6C6C8)
val LightToolbarBackground = Color(0xFFF9F9F9)
val LightCardBackground = Color(0xFFFFFFFF)
val LightOverlay = Color(0x66000000)

// Dark theme colors — iOS-inspired
val DarkBackground = Color(0xFF000000)
val DarkSurface = Color(0xFF1C1C1E)
val DarkOnBackground = Color(0xFFFFFFFF)
val DarkOnSurface = Color(0xFFF2F2F7)
val DarkPrimary = Color(0xFF0A84FF)
val DarkSecondary = Color(0xFF8E8E93)
val DarkSeparator = Color(0xFF38383A)
val DarkToolbarBackground = Color(0xFF1C1C1E)
val DarkCardBackground = Color(0xFF2C2C2E)
val DarkOverlay = Color(0x66000000)

// Button highlight
val ButtonActive = Color(0xFF007AFF)
val ButtonActiveDark = Color(0xFF0A84FF)
val ButtonInactive = Color(0xFF8E8E93)
