package com.mdeditor.app.util

import android.os.Build
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import android.graphics.RenderEffect
import android.graphics.Shader

object BlurUtils {
    /**
     * Applies background blur effect on API 31+, no-op on lower versions.
     * On lower API levels, use a semi-transparent background overlay instead.
     */
    fun Modifier.blurEffect(radius: Float): Modifier {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            this.graphicsLayer {
                renderEffect = RenderEffect
                    .createBlurEffect(radius, radius, Shader.TileMode.CLAMP)
                    .asComposeRenderEffect()
            }
        } else {
            this
        }
    }

    /**
     * Returns the appropriate overlay alpha for non-blur fallback.
     */
    val fallbackOverlayAlpha: Float
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) 0.3f else 0.4f
}
