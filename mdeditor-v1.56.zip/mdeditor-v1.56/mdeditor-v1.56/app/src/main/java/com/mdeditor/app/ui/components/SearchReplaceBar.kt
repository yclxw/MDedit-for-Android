package com.mdeditor.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mdeditor.app.ui.theme.ButtonActive

data class SearchState(
    val visible: Boolean = false,
    val findText: String = "",
    val replaceText: String = ""
)

@Composable
fun SearchReplaceBar(
    searchState: SearchState,
    onFindTextChange: (String) -> Unit,
    onReplaceTextChange: (String) -> Unit,
    onFindNext: () -> Unit,
    onFindPrevious: () -> Unit,
    onReplace: () -> Unit,
    onReplaceAll: () -> Unit,
    onClose: () -> Unit,
    matchCount: Int = 0,
    currentMatch: Int = 0,
    modifier: Modifier = Modifier
) {
    if (!searchState.visible) return

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant,
        tonalElevation = 4.dp
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            // Find row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Find input
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .background(
                            MaterialTheme.colorScheme.surface,
                            RoundedCornerShape(8.dp)
                        )
                        .padding(horizontal = 10.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (searchState.findText.isEmpty()) {
                        Text(
                            "查找...",
                            color = MaterialTheme.colorScheme.secondary,
                            fontSize = 14.sp
                        )
                    }
                    BasicTextField(
                        value = searchState.findText,
                        onValueChange = onFindTextChange,
                        singleLine = true,
                        textStyle = TextStyle(
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        cursorBrush = SolidColor(ButtonActive),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(Modifier.width(4.dp))

                // Match count
                if (searchState.findText.isNotEmpty()) {
                    Text(
                        "${currentMatch}/$matchCount",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                }

                // Nav buttons
                IconButton(
                    onClick = onFindPrevious,
                    modifier = Modifier.size(32.dp)
                ) {
                    Text("▲", fontSize = 12.sp)
                }
                IconButton(
                    onClick = onFindNext,
                    modifier = Modifier.size(32.dp)
                ) {
                    Text("▼", fontSize = 12.sp)
                }
                IconButton(
                    onClick = onClose,
                    modifier = Modifier.size(32.dp)
                ) {
                    Text("✕", fontSize = 14.sp, color = MaterialTheme.colorScheme.secondary)
                }
            }

            Spacer(Modifier.height(4.dp))

            // Replace row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .background(
                            MaterialTheme.colorScheme.surface,
                            RoundedCornerShape(8.dp)
                        )
                        .padding(horizontal = 10.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (searchState.replaceText.isEmpty()) {
                        Text(
                            "替换为...",
                            color = MaterialTheme.colorScheme.secondary,
                            fontSize = 14.sp
                        )
                    }
                    BasicTextField(
                        value = searchState.replaceText,
                        onValueChange = onReplaceTextChange,
                        singleLine = true,
                        textStyle = TextStyle(
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        cursorBrush = SolidColor(ButtonActive),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(Modifier.width(4.dp))

                TextButton(
                    onClick = onReplace,
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    Text("替换", fontSize = 13.sp)
                }
                TextButton(
                    onClick = onReplaceAll,
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    Text("全部", fontSize = 13.sp)
                }
            }
        }
    }
}
