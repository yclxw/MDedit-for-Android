package com.mdeditor.app.ui.components

import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.mdeditor.app.ui.theme.DarkPrimary
import com.mdeditor.app.ui.theme.LightPrimary

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MarkdownPreview(markdown: String, isDark: Boolean, modifier: Modifier = Modifier) {
    val html = remember(markdown, isDark) { buildPreviewHtml(markdown, isDark) }

    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = false
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                isVerticalScrollBarEnabled = true
                webViewClient = WebViewClient()
            }
        },
        modifier = modifier,
        update = { webView ->
            webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
        }
    )
}

private fun buildPreviewHtml(md: String, isDark: Boolean): String {
    val bg = if (isDark) "#000000" else "#F2F2F7"
    val fg = if (isDark) "#FFFFFF" else "#000000"
    val sec = if (isDark) "#8E8E93" else "#8E8E93"
    val codeBg = if (isDark) "#1C1C1E" else "#F0F0F3"
    val link = if (isDark) "#0A84FF" else "#007AFF"
    val border = if (isDark) "#38383A" else "#C6C6C8"

    val body = md.ifEmpty { " " }.lines().joinToString("\n") { line ->
        val trimmed = line.trimStart()
        when {
            trimmed.startsWith("##### ") -> "<h5>${colorize(esc(trimmed.removePrefix("##### ")))}</h5>"
            trimmed.startsWith("#### ") -> "<h4>${colorize(esc(trimmed.removePrefix("#### ")))}</h4>"
            trimmed.startsWith("### ") -> "<h3>${colorize(esc(trimmed.removePrefix("### ")))}</h3>"
            trimmed.startsWith("## ") -> "<h2>${colorize(esc(trimmed.removePrefix("## ")))}</h2>"
            trimmed.startsWith("# ") -> "<h1>${colorize(esc(trimmed.removePrefix("# ")))}</h1>"
            trimmed.matches(Regex("""^\d+\.\s+.*""")) -> {
                val content = esc(trimmed.replaceFirst(Regex("""^\d+\.\s+"""), ""))
                "<p style='margin-bottom:4px'>&nbsp;&nbsp;${colorize(content)}</p>"
            }
            line.isBlank() -> "<br>"
            else -> "<p>${colorize(esc(line))}</p>"
        }
    }
    return """<!DOCTYPE html><html><head>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box}body{font-family:-apple-system,'Segoe UI',Inter,sans-serif;font-size:17px;line-height:1.6;color:$fg;background:$bg;margin:0;padding:16px;-webkit-text-size-adjust:100%}
h1{font-size:28px;font-weight:bold;color:$fg;margin:24px 0 12px}
h2{font-size:24px;font-weight:bold;color:$fg;margin:20px 0 10px}
h3{font-size:20px;font-weight:600;color:$fg;margin:18px 0 8px}
h4{font-size:18px;font-weight:600;color:$fg;margin:16px 0 6px}
h5{font-size:16px;font-weight:600;color:$sec;margin:14px 0 4px}
p{margin:0 0 8px}
code{background:$codeBg;padding:2px 6px;border-radius:4px;font-family:monospace;font-size:15px}
pre{background:$codeBg;padding:12px;border-radius:8px;overflow-x:auto;margin:12px 0}
pre code{background:transparent;padding:0}
blockquote{border-left:3px solid $border;margin:12px 0;padding:4px 0 4px 16px;color:$sec}
a{color:$link;text-decoration:none}
hr{border:none;border-top:1px solid $border;margin:20px 0}
</style></head><body>$body</body></html>""".trimIndent()
}

private fun esc(s: String) = s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")

private val colorTagRegex = Regex("""\[c=#([0-9A-Fa-f]{6})](.*?)\[/c]""")

/** Convert [c=#RRGGBB]text[/c] → <span style='color:#RRGGBB'>text</span> */
private fun colorize(s: String): String =
    s.replace(colorTagRegex) { mr ->
        val hex = mr.groupValues[1]
        val text = mr.groupValues[2]
        "<span style='color:#$hex'>$text</span>"
    }
