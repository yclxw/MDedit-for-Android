package com.mdeditor.app.util

import com.mdeditor.app.util.LineParser.LineType.*
import org.junit.Assert.*
import org.junit.Test

class LineParserTest {

    // --- Heading detection ---

    @Test
    fun `parse H2 with space`() {
        assertEquals(HEADING_2, LineParser.parse("## 标题"))
    }

    @Test
    fun `parse H3 with space`() {
        assertEquals(HEADING_3, LineParser.parse("### 标题"))
    }

    @Test
    fun `parse H4 with space`() {
        assertEquals(HEADING_4, LineParser.parse("#### 标题"))
    }

    @Test
    fun `parse heading without space after hashes`() {
        // "###标题（无空格视为标题）" — spec says treat as heading
        assertEquals(HEADING_3, LineParser.parse("###标题"))
    }

    @Test
    fun `parse heading with leading whitespace`() {
        assertEquals(HEADING_2, LineParser.parse("  ## 标题"))
    }

    @Test
    fun `parse H2 with no text after marker`() {
        assertEquals(HEADING_2, LineParser.parse("##"))
    }

    @Test
    fun `parse H1 is ignored (treated as body)`() {
        assertEquals(BODY, LineParser.parse("# 标题"))
    }

    @Test
    fun `parse H5+ is ignored`() {
        assertEquals(BODY, LineParser.parse("##### 标题"))
    }

    @Test
    fun `parse too many hashes as body`() {
        assertEquals(BODY, LineParser.parse("###### 标题"))
    }

    // --- Ordered list detection ---

    @Test
    fun `parse simple ordered list`() {
        assertEquals(ORDERED_LIST, LineParser.parse("1. 项目"))
    }

    @Test
    fun `parse indented ordered list`() {
        assertEquals(ORDERED_LIST, LineParser.parse("  2. 子项目"))
    }

    @Test
    fun `parse ordered list with multi-digit number`() {
        assertEquals(ORDERED_LIST, LineParser.parse("10. 项目"))
    }

    @Test
    fun `parse ordered list without space after dot`() {
        assertEquals(BODY, LineParser.parse("1.item"))
    }

    @Test
    fun `parse ordered list with only dot no space`() {
        assertEquals(BODY, LineParser.parse("1."))
    }

    // --- Body detection ---

    @Test
    fun `parse plain text as body`() {
        assertEquals(BODY, LineParser.parse("这是一段正文"))
    }

    @Test
    fun `parse empty line as body`() {
        assertEquals(BODY, LineParser.parse(""))
    }

    @Test
    fun `parse whitespace-only line as body`() {
        assertEquals(BODY, LineParser.parse("   "))
    }

    // --- Content extraction ---

    @Test
    fun `getContent from H2`() {
        assertEquals("标题内容", LineParser.getContent("## 标题内容"))
    }

    @Test
    fun `getContent from H3 without space`() {
        assertEquals("标题", LineParser.getContent("###标题"))
    }

    @Test
    fun `getContent from H2 with no text`() {
        assertEquals("", LineParser.getContent("##"))
    }

    @Test
    fun `getContent from ordered list`() {
        assertEquals("项目内容", LineParser.getContent("1. 项目内容"))
    }

    @Test
    fun `getContent from indented ordered list`() {
        assertEquals("子项目", LineParser.getContent("  2. 子项目"))
    }

    @Test
    fun `getContent from body returns line unchanged`() {
        assertEquals("普通文本", LineParser.getContent("普通文本"))
    }

    // --- Indent spaces ---

    @Test
    fun `getIndentSpaces for no indent`() {
        assertEquals(0, LineParser.getIndentSpaces("1. 项目"))
    }

    @Test
    fun `getIndentSpaces for 2-space indent`() {
        assertEquals(2, LineParser.getIndentSpaces("  2. 项目"))
    }

    @Test
    fun `getIndentSpaces for 4-space indent`() {
        assertEquals(4, LineParser.getIndentSpaces("    3. 项目"))
    }

    @Test
    fun `getIndentSpaces for 6-space indent`() {
        assertEquals(6, LineParser.getIndentSpaces("      4. 项目"))
    }

    @Test
    fun `getIndentSpaces returns 0 for non-list`() {
        assertEquals(0, LineParser.getIndentSpaces("## 标题"))
    }

    // --- Heading level ---

    @Test
    fun `getHeadingLevel for H2`() {
        assertEquals(2, LineParser.getHeadingLevel("## 标题"))
    }

    @Test
    fun `getHeadingLevel for H3`() {
        assertEquals(3, LineParser.getHeadingLevel("### 标题"))
    }

    @Test
    fun `getHeadingLevel for H4`() {
        assertEquals(4, LineParser.getHeadingLevel("#### 标题"))
    }

    @Test
    fun `getHeadingLevel returns 0 for body`() {
        assertEquals(0, LineParser.getHeadingLevel("正文"))
    }

    // --- List number ---

    @Test
    fun `getListNumber extracts correct number`() {
        assertEquals(5, LineParser.getListNumber("5. 项目"))
    }

    @Test
    fun `getListNumber returns 0 for non-list`() {
        assertEquals(0, LineParser.getListNumber("## 标题"))
    }

    // --- Prefix builders ---

    @Test
    fun `headingPrefix builds correct marker`() {
        assertEquals("## ", LineParser.headingPrefix(2))
        assertEquals("### ", LineParser.headingPrefix(3))
        assertEquals("#### ", LineParser.headingPrefix(4))
    }

    @Test
    fun `listPrefix builds correct marker`() {
        assertEquals("1. ", LineParser.listPrefix(0, 1))
        assertEquals("  2. ", LineParser.listPrefix(2, 2))
        assertEquals("    3. ", LineParser.listPrefix(4, 3))
    }

    // --- Edge cases ---

    @Test
    fun `hash in middle of text is body`() {
        assertEquals(BODY, LineParser.parse("text ## not heading"))
    }

    @Test
    fun `number dot in middle of text is body`() {
        assertEquals(BODY, LineParser.parse("text 1. not list"))
    }

    @Test
    fun `indent not multiple of 2 still works`() {
        assertEquals(ORDERED_LIST, LineParser.parse("   1. 项目"))
        assertEquals(3, LineParser.getIndentSpaces("   1. 项目"))
    }
}
