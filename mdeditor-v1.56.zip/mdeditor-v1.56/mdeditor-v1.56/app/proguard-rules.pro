# ProGuard rules for MD Editor
# Markwon
-keep class org.commonmark.** { *; }
-dontwarn io.noties.markwon.**
