package com.mdeditor.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher

import android.view.Gravity
import android.widget.EditText
import android.widget.Toast
import androidx.compose.ui.graphics.toArgb
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mdeditor.app.ui.components.ColorPickerDialog
import com.mdeditor.app.ui.components.FormatAction
import com.mdeditor.app.ui.components.FormatBar
import com.mdeditor.app.ui.components.MarkdownPreview
import com.mdeditor.app.ui.components.SearchReplaceBar
import com.mdeditor.app.ui.components.SearchState
import com.mdeditor.app.ui.screens.RecentFilesDialog
import com.mdeditor.app.ui.screens.SettingsDialog
import com.mdeditor.app.ui.theme.MDEditorTheme
import com.mdeditor.app.util.AppSettings
import com.mdeditor.app.util.LineParser
import com.mdeditor.app.viewmodel.EditorViewModel
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Extract incoming file URI from intent (supports file manager, WeChat, etc.)
        val incomingUri: Uri? = run {
            val data = intent?.data
            if (data != null) return@run data
            // WeChat & share sheet: ACTION_SEND with EXTRA_STREAM
            if (intent?.action == Intent.ACTION_SEND) {
                @Suppress("DEPRECATION")
                val stream = intent?.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                if (stream != null) return@run stream
            }
            // Multiple items via ClipData
            intent?.clipData?.getItemAt(0)?.uri
        }

        setContent {
            MDEditorTheme {
                var showLeftMenu by remember { mutableStateOf(false) }
                var showRightMenu by remember { mutableStateOf(false) }
                val viewModel: EditorViewModel = viewModel()
                val editorText by viewModel.editorText.collectAsState()
                val isPreviewMode by viewModel.isPreviewMode.collectAsState()
                val fileName by viewModel.currentFileName.collectAsState()
                val currentLineType by viewModel.currentLineType.collectAsState()
                val context = LocalContext.current

                val appSettings = remember { AppSettings(context) }
                val autoNumberHeadings by appSettings.autoRenumberHeadings.collectAsState(initial = true)
                val fontSize by appSettings.fontSize.collectAsState(initial = 17)
                LaunchedEffect(autoNumberHeadings) { viewModel.autoNumberHeadings = autoNumberHeadings }

                // Handle incoming file from external intent (file manager, WeChat, share sheet)
                LaunchedEffect(incomingUri) {
                    val uri = incomingUri
                    if (uri != null) {
                        loadFileFromUri(uri, viewModel, context, appSettings)
                    }
                }

                val draftText by appSettings.draftText.collectAsState(initial = "")
                val draftUri by appSettings.draftUri.collectAsState(initial = "")
                LaunchedEffect(Unit) {
                    if (draftText.isNotEmpty()) {
                        viewModel.setEditorText(draftText)
                        if (draftUri.isNotEmpty()) {
                            try {
                                viewModel.setCurrentFile(Uri.parse(draftUri), fileNameFromUri(Uri.parse(draftUri)))
                            } catch (_: Exception) { }
                        }
                        viewModel.isModified.value.let { } // mark as modified already
                    }
                }

                // --- Auto-save draft on text change (debounced, survives process kill) ---
                val coroutineScope = rememberCoroutineScope()
                LaunchedEffect(editorText, viewModel.isModified.value) {
                    if (editorText.isNotEmpty() && viewModel.isModified.value) {
                        // Debounce 500ms — save only after user stops typing
                        kotlinx.coroutines.delay(500)
                        if (editorText == viewModel.editorText.value) {
                            appSettings.saveDraft(editorText, viewModel.currentFileUri.value?.toString())
                        }
                    }
                }
                var showSettings by remember { mutableStateOf(false) }
                var showRecentFiles by remember { mutableStateOf(false) }
                var showAbout by remember { mutableStateOf(false) }
                var showColorPicker by remember { mutableStateOf(false) }
                var showJumpDialog by remember { mutableStateOf(false) }

                var searchState by remember { mutableStateOf(SearchState()) }
                var searchMatches by remember { mutableStateOf(emptyList<Int>()) }
                var currentSearchIndex by remember { mutableStateOf(0) }

                val openLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.OpenDocument()
                ) { uri: Uri? ->
                    uri?.let {
                        loadFileFromUri(it, viewModel, context, appSettings)
                        coroutineScope.launch { appSettings.clearDraft() }
                    }
                }

                val saveLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.CreateDocument("text/markdown")
                ) { uri: Uri? ->
                    uri?.let {
                        saveToUri(it, viewModel, context, appSettings)
                        coroutineScope.launch { appSettings.clearDraft() }
                    }
                }

                val exportMdLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.CreateDocument("text/markdown")
                ) { uri: Uri? -> uri?.let { exportToUri(it, viewModel, context, "md") } }
                val exportTxtLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.CreateDocument("text/plain")
                ) { uri: Uri? -> uri?.let { exportToUri(it, viewModel, context, "txt") } }
                val exportHtmlLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.CreateDocument("text/html")
                ) { uri: Uri? -> uri?.let { exportToUri(it, viewModel, context, "html") } }

                // EditText ref at outer scope — accessible by both FormatBar and EditorView
                var editTextRef by remember { mutableStateOf<EditText?>(null) }

                // Format action handler — calculates line range from EditText selection
                fun handleFormatAction(action: FormatAction) {
                    val editText = editTextRef ?: return
                    val selStart = editText.selectionStart
                    val selEnd = editText.selectionEnd
                    val text = viewModel.editorText.value

                    val startLine = text.substring(0, selStart.coerceAtMost(text.length)).count { it == '\n' }
                    val endLine = if (selStart == selEnd) startLine + 1
                        else text.substring(0, selEnd.coerceAtMost(text.length)).count { it == '\n' } + 1

                    val useRange = selStart != selEnd
                    when (action) {
                        FormatAction.BODY -> {
                            if (useRange) viewModel.applyHeadingRange(startLine, endLine, 0)
                            else viewModel.applyHeading(startLine, 0)
                        }
                        FormatAction.H1 -> {
                            if (useRange) viewModel.applyHeadingRange(startLine, endLine, 1)
                            else viewModel.applyHeading(startLine, 1)
                        }
                        FormatAction.H2 -> {
                            if (useRange) viewModel.applyHeadingRange(startLine, endLine, 2)
                            else viewModel.applyHeading(startLine, 2)
                        }
                        FormatAction.H3 -> {
                            if (useRange) viewModel.applyHeadingRange(startLine, endLine, 3)
                            else viewModel.applyHeading(startLine, 3)
                        }
                        FormatAction.H4 -> {
                            if (useRange) viewModel.applyHeadingRange(startLine, endLine, 4)
                            else viewModel.applyHeading(startLine, 4)
                        }
                        FormatAction.H5 -> {
                            if (useRange) viewModel.applyHeadingRange(startLine, endLine, 5)
                            else viewModel.applyHeading(startLine, 5)
                        }
                        FormatAction.INDENT_LEFT -> {
                            if (useRange) viewModel.changeIndentRange(startLine, endLine, -1)
                            else viewModel.changeIndent(startLine, -1)
                        }
                        FormatAction.INDENT_RIGHT -> {
                            if (useRange) viewModel.changeIndentRange(startLine, endLine, 1)
                            else viewModel.changeIndent(startLine, 1)
                        }
                        FormatAction.BOLD -> {
                            val et = editTextRef ?: return@handleFormatAction
                            val ss = et.selectionStart
                            val se = et.selectionEnd
                            val txt = viewModel.editorText.value
                            if (ss < se) {
                                val selected = txt.substring(ss, se)
                                val newText = txt.substring(0, ss) + "**" + selected + "**" + txt.substring(se)
                                viewModel.updateEditorText(newText)
                            } else {
                                // Insert bold marker and place cursor between
                                val newText = txt.substring(0, ss) + "****" + txt.substring(ss)
                                viewModel.updateEditorText(newText)
                                et.post { et.setSelection(ss + 2) }
                            }
                        }
                        FormatAction.COLOR_PICKER -> {
                            showColorPicker = true
                        }
                        FormatAction.MOVE_UP -> {
                            if (useRange) viewModel.moveLineUpRange(startLine, endLine)
                            else viewModel.moveLineUp(startLine)
                        }
                        FormatAction.MOVE_DOWN -> {
                            if (useRange) viewModel.moveLineDownRange(startLine, endLine)
                            else viewModel.moveLineDown(startLine)
                        }
                        FormatAction.ORDERED_LIST -> {
                            if (useRange) viewModel.toggleOrderedListRange(startLine, endLine)
                            else viewModel.toggleOrderedList(startLine)
                        }
                    }
                    viewModel.clearCurrentLineType()
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        topBar = {
                            Column {
                                NavBar(
                                    title = fileName,
                                    onMenuClick = { showLeftMenu = true },
                                    onMoreClick = { showRightMenu = true }
                                )
                                FormatBar(
                                    currentLineType = currentLineType,
                                    onAction = { handleFormatAction(it) },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    ) { innerPadding ->
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                                .background(if (isPreviewMode) MaterialTheme.colorScheme.background else androidx.compose.ui.graphics.Color(0xFFE8F5E9))
                        ) {
                            val isDark = isSystemInDarkTheme()

                            if (isPreviewMode) {
                                MarkdownPreview(
                                    markdown = editorText,
                                    isDark = isDark,
                                    modifier = Modifier.weight(1f)
                                )
                            } else {

                                SearchReplaceBar(
                                    searchState = searchState,
                                    onFindTextChange = { text ->
                                        searchState = searchState.copy(findText = text)
                                        currentSearchIndex = 0
                                        searchMatches = if (text.isNotEmpty()) editorText.indicesOf(text) else emptyList()
                                    },
                                    onReplaceTextChange = { text ->
                                        searchState = searchState.copy(replaceText = text)
                                    },
                                    onFindNext = {
                                        if (searchMatches.isNotEmpty()) {
                                            currentSearchIndex = (currentSearchIndex + 1) % searchMatches.size
                                            editTextRef?.setSelection(
                                                searchMatches[currentSearchIndex],
                                                searchMatches[currentSearchIndex] + searchState.findText.length
                                            )
                                        }
                                    },
                                    onFindPrevious = {
                                        if (searchMatches.isNotEmpty()) {
                                            currentSearchIndex = if (currentSearchIndex == 0) searchMatches.size - 1
                                                else currentSearchIndex - 1
                                            editTextRef?.setSelection(
                                                searchMatches[currentSearchIndex],
                                                searchMatches[currentSearchIndex] + searchState.findText.length
                                            )
                                        }
                                    },
                                    onReplace = {
                                        if (searchMatches.isNotEmpty() && searchState.replaceText.isNotEmpty()) {
                                            val idx = searchMatches[currentSearchIndex]
                                            val before = editorText.substring(0, idx)
                                            val after = editorText.substring(idx + searchState.findText.length)
                                            val newText = before + searchState.replaceText + after
                                            viewModel.updateEditorText(newText)
                                            searchMatches = newText.indicesOf(searchState.findText)
                                        }
                                    },
                                    onReplaceAll = {
                                        if (searchState.findText.isNotEmpty()) {
                                            viewModel.updateEditorText(
                                                editorText.replace(searchState.findText, searchState.replaceText)
                                            )
                                            searchMatches = emptyList()
                                        }
                                    },
                                    onClose = {
                                        searchState = SearchState()
                                        searchMatches = emptyList()
                                    },
                                    matchCount = searchMatches.size,
                                    currentMatch = if (searchMatches.isEmpty()) 0 else currentSearchIndex + 1
                                )

                                EditorView(
                                    text = editorText,
                                    onTextChange = { viewModel.updateEditorText(it) },
                                    onCursorChange = { lineIndex -> viewModel.updateCurrentLineType(lineIndex) },
                                    onEnterPressed = { viewModel.getAutoNumberText(it) },
                                    editTextRef = { editTextRef = it },
                                    showLineNumbers = viewModel.showLineNumbers.collectAsState().value,
                                    fontSize = fontSize,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                // Left dropdown — zero-height overlay at top-left
                Row(Modifier.fillMaxWidth().height(0.dp), horizontalArrangement = Arrangement.Start) {
                    LeftDropdownMenu(
                        expanded = showLeftMenu,
                        onDismiss = { showLeftMenu = false },
                        onItemClick = { item ->
                            when (item) {
                                "new_md" -> {
                                    viewModel.resetState()
                                    coroutineScope.launch { appSettings.clearDraft() }
                                    showToast(context, "新建 MD 文档")
                                }
                                "open" -> openLauncher.launch(arrayOf("text/*"))
                                "save" -> {
                                    val uri = viewModel.currentFileUri.value
                                    if (uri != null) {
                                        saveToUri(uri, viewModel, context, appSettings)
                                        coroutineScope.launch { appSettings.clearDraft() }
                                    }
                                    else saveLauncher.launch("untitled.md")
                                }
                                "close" -> {
                                    viewModel.resetState()
                                    coroutineScope.launch { appSettings.clearDraft() }
                                    showToast(context, "已关闭")
                                }
                                "settings" -> showSettings = true
                                "recent" -> showRecentFiles = true
                                "about" -> showAbout = true
                                else -> handleDrawerExport(item, exportMdLauncher, exportTxtLauncher, exportHtmlLauncher, fileName)
                            }
                        }
                    )
                }

                // Right dropdown — zero-height overlay at top-right
                Row(Modifier.fillMaxWidth().height(0.dp), horizontalArrangement = Arrangement.End) {
                    RightDropdownMenu(
                        expanded = showRightMenu,
                        onDismiss = { showRightMenu = false },
                        onItemClick = { item ->
                            when (item) {
                                "edit_mode" -> viewModel.setPreviewMode(false)
                                "preview_mode" -> viewModel.setPreviewMode(true)
                                "scroll_top" -> editTextRef?.scrollTo(0, 0)
                                "jump_line" -> showJumpDialog = true
                                "find_replace" -> searchState = SearchState(visible = true)
                                else -> handleMenuAction(item, viewModel, context, editTextRef)
                            }
                        }
                    )
                }
            } // Box

                // --- Dialogs ---
                if (showSettings) {
                    SettingsDialog(
                        settings = appSettings,
                        onDismiss = { showSettings = false },
                        onThemeChanged = { }
                    )
                }
                if (showRecentFiles) {
                    val recentJson by appSettings.recentFiles.collectAsState(initial = "[]")
                    val recentList = remember(recentJson) { parseRecentJson(recentJson) }
                    RecentFilesDialog(
                        files = recentList,
                        onFileClick = { uri ->
                            showRecentFiles = false
                            try {
                                loadFileFromUri(Uri.parse(uri), viewModel, context, appSettings)
                            } catch (_: Exception) {
                                showToast(context, "文件不存在或无权限访问")
                            }
                        },
                        onDismiss = { showRecentFiles = false }
                    )
                }
                if (showAbout) {
                    AlertDialog(
                        onDismissRequest = { showAbout = false },
                        title = { Text("关于 MD编辑器") },
                        text = {
                            Text(
                                "版本：v1.54\n作者：帅气的锅巴"
                            )
                        },
                        confirmButton = {
                            TextButton(onClick = { showAbout = false }) { Text("确定") }
                        }
                    )
                }

                if (showColorPicker) {
                    ColorPickerDialog(
                        onColorSelected = { color ->
                            showColorPicker = false
                            val et = editTextRef ?: return@ColorPickerDialog
                            val ss = et.selectionStart
                            val se = et.selectionEnd
                            if (ss < se) {
                                val hex = String.format("%06X", color.toArgb() and 0xFFFFFF)
                                val txt = viewModel.editorText.value
                                val selected = txt.substring(ss, se)
                                val newText = txt.substring(0, ss) + "[c=#$hex]$selected[/c]" + txt.substring(se)
                                viewModel.updateEditorText(newText)
                                et.post { et.setSelection(ss + "[c=#$hex]".length + selected.length + "[/c]".length) }
                            }
                        },
                        onDismiss = { showColorPicker = false }
                    )
                }

                if (showJumpDialog) {
                    var jumpInput by remember { mutableStateOf("") }
                    AlertDialog(
                        onDismissRequest = { showJumpDialog = false },
                        title = { Text("跳转到行") },
                        text = {
                            OutlinedTextField(
                                value = jumpInput,
                                onValueChange = { jumpInput = it.filter { c -> c.isDigit() } },
                                label = { Text("输入行号") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                val lineNum = jumpInput.toIntOrNull()
                                if (lineNum != null && lineNum > 0) {
                                    val et = editTextRef
                                    val text = viewModel.editorText.value
                                    val lines = text.lines()
                                    if (lineNum <= lines.size) {
                                        // Calculate position of the target line
                                        val pos = lines.take(lineNum - 1).sumOf { it.length + 1 }
                                        et?.setSelection(pos.coerceAtMost(text.length))
                                        // Scroll to make selection visible
                                        et?.post {
                                            val layout = et.layout
                                            if (layout != null && et.selectionStart < text.length) {
                                                val line = layout.getLineForOffset(et.selectionStart)
                                                val y = layout.getLineTop(line) - et.paddingTop
                                                et.scrollTo(0, y.coerceAtLeast(0))
                                            }
                                        }
                                    }
                                }
                                showJumpDialog = false
                            }) { Text("跳转") }
                        },
                        dismissButton = {
                            TextButton(onClick = { showJumpDialog = false }) { Text("取消") }
                        }
                    )
                }
            }
        }
    }
}

// --- Extension ---

private fun parseRecentJson(json: String): List<Pair<String, String>> {
    if (json == "[]" || json.isBlank()) return emptyList()
    val clean = json.removeSurrounding("[", "]")
    if (clean.isBlank()) return emptyList()
    return clean.split("},{").map { entry ->
        val cleaned = entry.removeSurrounding("{", "}")
        val uri = cleaned.substringAfter("\"uri\":\"").substringBefore("\"")
        val name = cleaned.substringAfter("\"name\":\"").substringBefore("\"")
        uri to name
    }
}

// --- Editor View ---

@Composable
fun EditorView(
    text: String,
    onTextChange: (String) -> Unit,
    onCursorChange: (Int) -> Unit,
    onEnterPressed: (String) -> String?,
    editTextRef: (EditText) -> Unit,
    showLineNumbers: Boolean = false,
    fontSize: Int = 17,
    modifier: Modifier = Modifier
) {
    val isUpdating = remember { AtomicBoolean(false) }
    val textWatchersSet = remember { AtomicBoolean(false) }
    val lineCount = remember(text) { text.lines().size.coerceAtLeast(1) }

    val textMeasurer = rememberTextMeasurer()
    var scrollY by remember { mutableIntStateOf(0) }
    // Real line metrics from EditText — updated after layout
    var editLineHeight by remember { mutableFloatStateOf(fontSize * 1.5f) }
    var editPaddingTop by remember { mutableFloatStateOf(8f) }

    Box(modifier = modifier) {
        AndroidView(
            modifier = Modifier
                .fillMaxSize()
                .padding(start = if (showLineNumbers) 44.dp else 0.dp, top = 8.dp, end = 8.dp, bottom = 8.dp),
            factory = { ctx ->
                EditText(ctx).apply {
                gravity = Gravity.TOP or Gravity.START
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                setTextSize(fontSize.toFloat())
                setPadding(8, 8, 8, 8)
                setHorizontallyScrolling(false)
                overScrollMode = android.view.View.OVER_SCROLL_ALWAYS
                isCursorVisible = true
                setSelectAllOnFocus(true)
                if (text.isNotEmpty()) setText(text)
                requestFocus()
                post { requestFocus() }
                editTextRef(this)
            }
        },
        update = { editText ->
            // Apply font size from settings
            editText.textSize = fontSize.toFloat()
            // Capture real line metrics for canvas alignment
            editPaddingTop = editText.paddingTop.toFloat()
            editLineHeight = editText.paint.fontSpacing
            // Sync line number scroll
            editText.setOnScrollChangeListener { _, _, _, _, _ ->
                scrollY = editText.scrollY
            }

            // Detect cursor movement (tap/click without text change)
            editText.setOnTouchListener { _, event ->
                if (event.action == android.view.MotionEvent.ACTION_UP) {
                    editText.post {
                        val pos = editText.selectionStart
                        val txt = editText.text.toString()
                        val line = txt.substring(0, pos.coerceAtMost(txt.length)).count { it == '\n' }
                        onCursorChange(line)
                    }
                }
                false
            }

            if (!textWatchersSet.getAndSet(true)) {
                editText.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        if (isUpdating.get()) return
                        val newText = s?.toString() ?: ""
                        if (newText != text) {
                            isUpdating.set(true)
                            onTextChange(newText)
                            isUpdating.set(false)
                        }
                        val cursorPos = editText.selectionStart
                        val textBeforeCursor = newText.substring(0, cursorPos.coerceAtMost(newText.length))
                        val lineIndex = textBeforeCursor.count { it == '\n' }
                        onCursorChange(lineIndex)
                    }
                })

                var lastText = editText.text.toString()
                editText.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        if (isUpdating.get()) return
                        val newText = s?.toString() ?: ""
                        if (newText.length > lastText.length && newText.contains("\n")) {
                            val cursorPos = editText.selectionStart
                            if (cursorPos > 0 && newText.getOrNull(cursorPos - 1) == '\n') {
                                val textBeforeNewline = newText.substring(0, cursorPos - 1)
                                val prevLine = textBeforeNewline.substringAfterLast('\n')
                                val autoText = onEnterPressed(prevLine)
                                if (autoText != null) {
                                    isUpdating.set(true)
                                    val before = newText.substring(0, cursorPos)
                                    val after = newText.substring(cursorPos)
                                    editText.setText(before + autoText + after)
                                    editText.setSelection(cursorPos + autoText.length)
                                    isUpdating.set(false)
                                }
                            }
                        }
                        lastText = editText.text.toString()
                    }
                })
            }

            if (isUpdating.get()) return@AndroidView
            if (editText.text.toString() != text) {
                isUpdating.set(true)
                val cursor = editText.selectionStart.coerceAtMost(text.length)
                editText.setText(text)
                editText.setSelection(cursor)
                isUpdating.set(false)
            }
        }
        ) // AndroidView

        // Line number overlay — drawn on Canvas, not constrained by layout
        if (showLineNumbers) {
            val lineNumColor = MaterialTheme.colorScheme.secondary
            Canvas(modifier = Modifier.fillMaxSize().padding(start = 4.dp, top = 8.dp, bottom = 8.dp)) {
                val startY = editPaddingTop - scrollY
                val style = TextStyle(
                    fontSize = fontSize.sp,
                    lineHeight = fontSize.sp,
                    color = lineNumColor
                )
                for (i in 1..lineCount) {
                    val y = startY + (i - 1) * editLineHeight
                    if (y + editLineHeight > 0 && y < size.height) {
                        drawText(
                            textMeasurer = textMeasurer,
                            text = i.toString(),
                            topLeft = Offset(0f, y),
                            style = style
                        )
                    }
                }
            }
        }
    } // Box
}

// --- NavBar ---

@Composable
fun NavBar(title: String, onMenuClick: () -> Unit, onMoreClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().statusBarsPadding().height(44.dp),
        color = MaterialTheme.colorScheme.surface
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left menu button
            Box(
                modifier = Modifier.size(40.dp).clickable(onClick = onMenuClick),
                contentAlignment = Alignment.Center
            ) {
                Text("⋮", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
            }
            var titleFontSize by remember(title) { mutableFloatStateOf(17f) }
            Text(
                title,
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = titleFontSize.sp
                ),
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
                maxLines = 2,
                softWrap = true,
                overflow = TextOverflow.Ellipsis,
                onTextLayout = { result ->
                    if (result.hasVisualOverflow && titleFontSize > 13f) {
                        titleFontSize = titleFontSize * 0.85f
                    }
                }
            )
            // Right menu button
            Box(
                modifier = Modifier.size(40.dp).clickable(onClick = onMoreClick),
                contentAlignment = Alignment.Center
            ) {
                Text("⋮", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
            }
        }
    }
}

// --- Left Dropdown ---

@Composable
private fun MenuItemRow(icon: String, label: String, onClick: () -> Unit) {
    DropdownMenuItem(
        text = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.width(28.dp), contentAlignment = Alignment.Center) {
                    Text(icon, style = MaterialTheme.typography.bodyLarge)
                }
                Spacer(Modifier.width(4.dp))
                Text(label, style = MaterialTheme.typography.bodyLarge)
            }
        },
        onClick = onClick
    )
}

@Composable
fun LeftDropdownMenu(expanded: Boolean, onDismiss: () -> Unit, onItemClick: (String) -> Unit) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        MenuItemRow("📝", "新建") { onItemClick("new_md"); onDismiss() }
        MenuItemRow("📂", "打开") { onItemClick("open"); onDismiss() }
        MenuItemRow("💾", "保存") { onItemClick("save"); onDismiss() }
        MenuItemRow("✕", "关闭") { onItemClick("close"); onDismiss() }
        MenuItemRow("📋", "日志") { onItemClick("recent"); onDismiss() }
        Divider()
        MenuItemRow("💾", "另存") { onItemClick("export_md"); onDismiss() }
        MenuItemRow("⚙️", "设置") { onItemClick("settings"); onDismiss() }
        MenuItemRow("ℹ️", "关于") { onItemClick("about"); onDismiss() }
    }
}

// --- Right Dropdown ---

@Composable
fun RightDropdownMenu(expanded: Boolean, onDismiss: () -> Unit, onItemClick: (String) -> Unit) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        MenuItemRow("✏️", "编辑模式") { onItemClick("edit_mode"); onDismiss() }
        MenuItemRow("👁", "预览模式") { onItemClick("preview_mode"); onDismiss() }
        Divider()
        MenuItemRow("⬆", "到顶端") { onItemClick("scroll_top"); onDismiss() }
        MenuItemRow("🔀", "跳转行") { onItemClick("jump_line"); onDismiss() }
        MenuItemRow("🔍", "查找与替换") { onItemClick("find_replace"); onDismiss() }
        MenuItemRow("📊", "字数统计") { onItemClick("word_count"); onDismiss() }
        Divider()
        MenuItemRow("📋", "全选") { onItemClick("select_all"); onDismiss() }
        MenuItemRow("✂", "剪切") { onItemClick("cut"); onDismiss() }
        MenuItemRow("📋", "复制") { onItemClick("copy"); onDismiss() }
        MenuItemRow("📋", "粘贴") { onItemClick("paste"); onDismiss() }
        Divider()
        MenuItemRow("🔢", "重新标题编号") { onItemClick("renumber_headings"); onDismiss() }
        MenuItemRow("🚫", "取消标题编号") { onItemClick("remove_heading_numbers"); onDismiss() }
        MenuItemRow("📝", "显示/隐藏行号") { onItemClick("toggle_line_numbers"); onDismiss() }
    }
}

// --- Handlers ---

private fun handleMenuAction(
    item: String,
    viewModel: EditorViewModel,
    context: android.content.Context,
    editText: EditText?
) {
    when (item) {
        "word_count" -> {
            val wc = viewModel.getWordCount()
            showToast(context, "字符: ${wc.charsWithSpaces} | 单词: ${wc.words} | 行数: ${wc.lines}")
        }
        "select_all" -> editText?.selectAll()
        "cut" -> {
            val et = editText ?: return
            val ss = et.selectionStart
            val se = et.selectionEnd
            if (ss != se) {
                val text = viewModel.editorText.value
                val selected = text.substring(
                    ss.coerceAtMost(text.length), se.coerceAtMost(text.length))
                val clip = android.content.ClipData.newPlainText("md", selected)
                (context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager)
                    ?.setPrimaryClip(clip)
                viewModel.updateEditorText(text.substring(0, ss) + text.substring(se))
            }
        }
        "copy" -> {
            val clip = android.content.ClipData.newPlainText("md", viewModel.editorText.value)
            (context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager)
                ?.setPrimaryClip(clip)
        }
        "paste" -> {
            val clip = (context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager)
                ?.primaryClip?.getItemAt(0)?.text?.toString()
            clip?.let { editText?.text?.insert(editText.selectionStart, it) }
        }
        "renumber_headings" -> {
            viewModel.forceRenumberHeadings()
            viewModel.renumberAllLists()
        }
        "remove_heading_numbers" -> {
            viewModel.removeHeadingNumbers()
            viewModel.renumberAllLists()
        }
        "toggle_line_numbers" -> viewModel.toggleLineNumbers()
    }
}

private fun handleDrawerExport(
    item: String,
    exportMdLauncher: androidx.activity.result.ActivityResultLauncher<String>,
    exportTxtLauncher: androidx.activity.result.ActivityResultLauncher<String>,
    exportHtmlLauncher: androidx.activity.result.ActivityResultLauncher<String>,
    currentName: String = "untitled.md"
) {
    val baseName = if (currentName == "MD编辑器") "untitled.md" else currentName
    when (item) {
        "export_md" -> exportMdLauncher.launch(baseName)
        "export_txt" -> exportTxtLauncher.launch(baseName.replace(".md", ".txt"))
        "export_html" -> exportHtmlLauncher.launch(baseName.replace(".md", ".html"))
    }
}

// --- File I/O ---

private fun fileNameFromUri(uri: Uri): String {
    // Extract just the filename from a content URI, stripping "primary:" prefix
    val last = uri.lastPathSegment ?: return "untitled.md"
    return try {
        val decoded = java.net.URLDecoder.decode(last, "UTF-8")
        decoded.substringAfterLast('/').removePrefix("primary:")
    } catch (_: Exception) {
        last.substringAfterLast('/').removePrefix("primary:")
    }
}

private fun loadFileFromUri(uri: Uri, viewModel: EditorViewModel, context: android.content.Context, settings: AppSettings? = null) {
    try {
        // Read file first — external intent already grants temporary read permission
        val content = context.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: ""
        val name = fileNameFromUri(uri)
        viewModel.setEditorText(content)
        viewModel.setCurrentFile(uri, name)
        viewModel.markSaved()
        // Persist URI permission if possible (non-fatal if denied)
        try {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: SecurityException) { }
        kotlinx.coroutines.runBlocking {
            settings?.addRecentFile(uri.toString(), name)
        }
        showToast(context, "文件已打开")
    } catch (e: Exception) {
        showToast(context, "打开文件失败: ${e.message}")
    }
}

private fun saveToUri(uri: Uri, viewModel: EditorViewModel, context: android.content.Context, settings: AppSettings? = null) {
    try {
        context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { writer ->
            writer.write(viewModel.editorText.value)
        }
        val name = fileNameFromUri(uri)
        viewModel.setCurrentFile(uri, name)
        viewModel.markSaved()
        try {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: SecurityException) { }
        kotlinx.coroutines.runBlocking {
            settings?.addRecentFile(uri.toString(), name)
        }
        showToast(context, "已保存")
    } catch (e: Exception) {
        showToast(context, "保存失败: ${e.message}")
    }
}

private fun exportToUri(uri: Uri, viewModel: EditorViewModel, context: android.content.Context, format: String) {
    try {
        val content = when (format) {
            "md" -> viewModel.editorText.value
            "txt" -> viewModel.editorText.value.lines().joinToString("\n") { LineParser.getContent(it) }
            "html" -> {
                val text = viewModel.editorText.value
                "<html><body><pre>${text.replace("<", "&lt;").replace(">", "&gt;")}</pre></body></html>"
            }
            else -> viewModel.editorText.value
        }
        context.contentResolver.takePersistableUriPermission(
            uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(content) }
        // "另存" switches to the new file
        if (format == "md") {
            viewModel.setCurrentFile(uri, fileNameFromUri(uri))
            viewModel.markSaved()
        }
        showToast(context, "导出成功 ($format)")
    } catch (e: Exception) {
        showToast(context, "导出失败: ${e.message}")
    }
}

private fun showToast(context: android.content.Context, message: String) {
    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
}

private fun String.indicesOf(substring: String): List<Int> {
    val indices = mutableListOf<Int>()
    var start = 0
    while (start < length) {
        val idx = indexOf(substring, start)
        if (idx == -1) break
        indices.add(idx)
        start = idx + 1
    }
    return indices
}
